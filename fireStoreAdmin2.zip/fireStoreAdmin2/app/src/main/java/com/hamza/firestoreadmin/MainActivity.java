package com.hamza.firestoreadmin;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;

import javax.annotation.Nullable;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    shiftAdapter shiftAdapter;
    private CollectionReference myCol = FirebaseFirestore.getInstance().collection("pendingShifts");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Query mQuery = myCol.orderBy("username", Query.Direction.ASCENDING);

        FirestoreRecyclerOptions<pendingShifts> options = new FirestoreRecyclerOptions.Builder<pendingShifts>()
                .setQuery(mQuery, pendingShifts.class)
                .build();

        shiftAdapter = new shiftAdapter(options,this);

        recyclerView = findViewById(R.id.postRV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(shiftAdapter);


    }


    @Override
    protected void onStart() {
        super.onStart();
        shiftAdapter.startListening();
    }
    @Override
    protected void onStop() {
        super.onStop();

        if (shiftAdapter != null) {
            shiftAdapter.stopListening();
        }
    }
    private void showMessage(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
    }


    private class myViewHolder extends RecyclerView.ViewHolder {
        private View view;



        myViewHolder(@NonNull View itemView) {

            super(itemView);
            view = itemView;


        }

        void setShiftName(String shiftName) {

            TextView card_title = view.findViewById(R.id.homeText1);

            card_title.setText(shiftName);

        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent backIntent = new Intent(getApplicationContext(), homeActivity.class);
        startActivity(backIntent);
        finish();
    }
}